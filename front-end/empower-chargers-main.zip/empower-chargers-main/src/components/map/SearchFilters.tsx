import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { Filter, RotateCcw, Search, Zap, AlertCircle, Info } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export interface FilterState {
  status: string[];
  powerRange: [number, number];
  hideUnderRepair: boolean;
  hideComingSoon: boolean;
}

interface SearchFiltersProps {
  onSearch: (filters: FilterState) => void;
  onClear: () => void;
}

// Available statuses from the dataset
const STATUS_OPTIONS = [
  { id: "AVAILABLE", label: "Available", color: "bg-success" },
  { id: "OFFLINE", label: "Offline", color: "bg-muted-foreground" },
  { id: "OCCUPIED", label: "Occupied", color: "bg-warning" },
  { id: "BUSY", label: "Busy", color: "bg-orange-500" },
];

// Power range from dataset: min=2, max=300
const POWER_MIN = 2;
const POWER_MAX = 300;

export function SearchFilters({ onSearch, onClear }: SearchFiltersProps) {
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>(["AVAILABLE"]);
  const [powerRange, setPowerRange] = useState<[number, number]>([POWER_MIN, POWER_MAX]);
  const [hideUnderRepair, setHideUnderRepair] = useState(false);
  const [hideComingSoon, setHideComingSoon] = useState(false);

  const toggleStatus = (statusId: string) => {
    setSelectedStatuses(prev => 
      prev.includes(statusId)
        ? prev.filter(s => s !== statusId)
        : [...prev, statusId]
    );
  };

  const handleSearch = () => {
    onSearch({
      status: selectedStatuses,
      powerRange,
      hideUnderRepair,
      hideComingSoon,
    });
  };

  const handleClear = () => {
    setSelectedStatuses(["AVAILABLE"]);
    setPowerRange([POWER_MIN, POWER_MAX]);
    setHideUnderRepair(false);
    setHideComingSoon(false);
    onClear();
  };

  const hasActiveFilters = 
    selectedStatuses.length !== 1 || 
    selectedStatuses[0] !== "AVAILABLE" ||
    powerRange[0] !== POWER_MIN || 
    powerRange[1] !== POWER_MAX ||
    hideUnderRepair ||
    hideComingSoon;

  return (
    <TooltipProvider>
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border bg-muted/30">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-primary" />
            <h2 className="font-semibold">Search Filters</h2>
          </div>
          {hasActiveFilters && (
            <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
              Active
            </span>
          )}
        </div>

        <div className="p-5 space-y-6">
          {/* Status Filter (Multi-select) */}
          <div>
            <label className="text-sm font-medium text-foreground mb-3 block">
              Status
            </label>
            <div className="grid grid-cols-2 gap-2">
              {STATUS_OPTIONS.map((status) => (
                <button
                  key={status.id}
                  onClick={() => toggleStatus(status.id)}
                  className={cn(
                    "px-3 py-2 rounded-lg border text-sm font-medium transition-all flex items-center gap-2",
                    selectedStatuses.includes(status.id)
                      ? "bg-primary text-primary-foreground border-primary shadow-sm"
                      : "bg-background border-border text-foreground hover:border-primary/50 hover:bg-accent/50"
                  )}
                >
                  <div className={cn("w-2 h-2 rounded-full", status.color)} />
                  {status.label}
                </button>
              ))}
            </div>
            {selectedStatuses.length === 0 && (
              <p className="text-xs text-muted-foreground mt-2">Select at least one status</p>
            )}
          </div>

          {/* Power Range Slider */}
          <div>
            <label className="text-sm font-medium text-foreground mb-3 block">
              Power Range (kW)
            </label>
            <div className="bg-muted/50 rounded-lg p-4">
              <Slider
                value={powerRange}
                onValueChange={(val) => setPowerRange(val as [number, number])}
                min={POWER_MIN}
                max={POWER_MAX}
                step={1}
                className="w-full"
              />
              <div className="flex justify-between items-center text-xs mt-3">
                <span className="text-muted-foreground">{POWER_MIN} kW</span>
                <span className="flex items-center gap-1 bg-primary/10 text-primary px-2 py-1 rounded-full font-medium">
                  <Zap className="h-3 w-3" />
                  {powerRange[0]} - {powerRange[1]} kW
                </span>
                <span className="text-muted-foreground">{POWER_MAX} kW</span>
              </div>
            </div>
          </div>

          {/* Connector Type - Not Available Notice */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <label className="text-sm font-medium text-muted-foreground">
                Connector Type
              </label>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent side="top" className="max-w-[200px]">
                  <p className="text-xs">Connector type data (Tesla, Type 2, CCS, etc.) is not available from the current API.</p>
                </TooltipContent>
              </Tooltip>
            </div>
            <div className="bg-muted/30 rounded-lg p-3 border border-dashed border-border">
              <p className="text-xs text-muted-foreground flex items-center gap-2">
                <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                Not available - API doesn't provide connector type data
              </p>
            </div>
          </div>

          {/* Location Toggles */}
          <div className="space-y-4">
            <label className="text-sm font-medium text-foreground block">
              Location Options
            </label>

            <div className="flex items-center justify-between">
              <Label htmlFor="hide-repair" className="text-sm cursor-pointer">
                Hide under repair
              </Label>
              <Switch
                id="hide-repair"
                checked={hideUnderRepair}
                onCheckedChange={setHideUnderRepair}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="hide-coming-soon" className="text-sm cursor-pointer">
                Hide coming soon
              </Label>
              <Switch
                id="hide-coming-soon"
                checked={hideComingSoon}
                onCheckedChange={setHideComingSoon}
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 p-5 pt-0">
          <Button 
            variant="outline" 
            className="flex-1 gap-2" 
            onClick={handleClear}
            disabled={!hasActiveFilters}
          >
            <RotateCcw className="h-4 w-4" />
            Reset
          </Button>
          <Button 
            className="flex-1 gap-2" 
            onClick={handleSearch}
            disabled={selectedStatuses.length === 0}
          >
            <Search className="h-4 w-4" />
            Apply
          </Button>
        </div>
      </div>
    </TooltipProvider>
  );
}
