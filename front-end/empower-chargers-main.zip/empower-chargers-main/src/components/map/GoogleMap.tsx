import { useCallback, useState, useMemo, useEffect } from "react";
import { GoogleMap, useJsApiLoader, Marker, InfoWindow } from "@react-google-maps/api";
import { LocationWithChargers } from "@/hooks/useChargingPoints";
import { Zap, ZoomIn, ZoomOut, Locate, Loader2, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";

const GOOGLE_MAPS_API_KEY = "AIzaSyCIQx4cPi6G5WvP4fypr5GP8wELU71uYT0";

interface GoogleMapComponentProps {
  locations: LocationWithChargers[];
  onLocationClick?: (location: LocationWithChargers) => void;
  selectedLocationId?: string | null;
}

const containerStyle = {
  width: "100%",
  height: "100%",
};

// Default center on Athens, Greece (fallback)
const defaultCenter = {
  lat: 37.9838,
  lng: 23.7275,
};

const mapOptions: google.maps.MapOptions = {
  disableDefaultUI: true,
  zoomControl: false,
  mapTypeControl: false,
  streetViewControl: false,
  fullscreenControl: false,
  styles: [
    {
      featureType: "poi",
      elementType: "labels",
      stylers: [{ visibility: "off" }],
    },
    {
      featureType: "water",
      elementType: "geometry.fill",
      stylers: [{ color: "#a3ccff" }],
    },
  ],
};

// Marker colors based on availability
const getMarkerIcon = (location: LocationWithChargers) => {
  let color = "#22c55e"; // green - available
  if (location.underRepair) {
    color = "#f59e0b"; // warning - under repair
  } else if (location.availableChargers === 0) {
    color = "#6b7280"; // gray - all in use
  }

  return {
    path: "M12 0C5.4 0 0 5.4 0 12c0 9 12 20 12 20s12-11 12-20c0-6.6-5.4-12-12-12z",
    fillColor: color,
    fillOpacity: 1,
    strokeColor: "#ffffff",
    strokeWeight: 2,
    scale: 1.2,
    anchor: new google.maps.Point(12, 32),
    labelOrigin: new google.maps.Point(12, 12),
  };
};

export function GoogleMapComponent({
  locations,
  onLocationClick,
  selectedLocationId,
}: GoogleMapComponentProps) {
  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: GOOGLE_MAPS_API_KEY,
  });

  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [hoveredLocation, setHoveredLocation] = useState<LocationWithChargers | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationRequested, setLocationRequested] = useState(false);

  // Request user location on mount
  useEffect(() => {
    if (locationRequested) return;
    setLocationRequested(true);

    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userPos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          setUserLocation(userPos);
          
          // Center map on user location if map is ready
          if (map) {
            map.setCenter(userPos);
            map.setZoom(15);
          }
          
          toast({
            title: "Location found",
            description: "Map centered on your location",
          });
        },
        (error) => {
          console.log("Geolocation error:", error.message);
          // Silently fall back to default center - don't bother user
        },
        {
          enableHighAccuracy: false,
          timeout: 10000,
          maximumAge: 300000, // Cache for 5 minutes
        }
      );
    }
  }, [locationRequested, map]);

  // Center on user location when map loads
  const initialCenter = userLocation || defaultCenter;
  const initialZoom = userLocation ? 15 : 13; // Closer zoom - don't need to show all chargers

  const onLoad = useCallback((mapInstance: google.maps.Map) => {
    setMap(mapInstance);
    
    // If we already have user location, center on it
    if (userLocation) {
      mapInstance.setCenter(userLocation);
      mapInstance.setZoom(15);
    }
  }, [userLocation]);

  const onUnmount = useCallback(() => {
    setMap(null);
  }, []);

  const handleZoomIn = () => {
    if (map) {
      map.setZoom((map.getZoom() || 11) + 1);
    }
  };

  const handleZoomOut = () => {
    if (map) {
      map.setZoom((map.getZoom() || 11) - 1);
    }
  };

  const handleLocateUser = () => {
    if (!("geolocation" in navigator)) {
      toast({
        title: "Location not available",
        description: "Your browser doesn't support geolocation",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Finding your location...",
    });

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userPos = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        setUserLocation(userPos);
        
        if (map) {
          map.setCenter(userPos);
          map.setZoom(14);
        }
        
        toast({
          title: "Location found",
          description: "Map centered on your location",
        });
      },
      (error) => {
        toast({
          title: "Location error",
          description: error.message || "Could not get your location",
          variant: "destructive",
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
      }
    );
  };

  const selectedLocation = useMemo(() => {
    return locations.find((loc) => loc.locationId === selectedLocationId);
  }, [locations, selectedLocationId]);

  if (loadError) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-muted">
        <div className="text-center text-muted-foreground">
          <p>Error loading Google Maps</p>
          <p className="text-sm">{loadError.message}</p>
        </div>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-muted">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          <span>Loading map...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full">
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={initialCenter}
        zoom={initialZoom}
        onLoad={onLoad}
        onUnmount={onUnmount}
        options={mapOptions}
      >
        {/* User location marker */}
        {userLocation && (
          <Marker
            position={userLocation}
            icon={{
              path: google.maps.SymbolPath.CIRCLE,
              fillColor: "#3b82f6",
              fillOpacity: 1,
              strokeColor: "#ffffff",
              strokeWeight: 3,
              scale: 8,
            }}
            title="Your location"
          />
        )}

        {locations.map((location) => (
          <Marker
            key={location.locationId}
            position={{ lat: location.latitude, lng: location.longitude }}
            icon={getMarkerIcon(location)}
            label={{
              text: String(location.availableChargers),
              color: "#1f2937",
              fontSize: "10px",
              fontWeight: "bold",
            }}
            onClick={() => onLocationClick?.(location)}
            onMouseOver={() => setHoveredLocation(location)}
            onMouseOut={() => setHoveredLocation(null)}
          />
        ))}

        {hoveredLocation && !selectedLocationId && (
          <InfoWindow
            position={{ lat: hoveredLocation.latitude, lng: hoveredLocation.longitude }}
            options={{ pixelOffset: new google.maps.Size(0, -35) }}
            onCloseClick={() => setHoveredLocation(null)}
          >
            <div className="p-1 min-w-[150px]">
              <h3 className="font-semibold text-sm text-gray-900">{hoveredLocation.name}</h3>
              <p className="text-xs text-gray-600">{hoveredLocation.address}</p>
              <div className="flex items-center gap-1 mt-1">
                <Zap className="h-3 w-3 text-green-600" />
                <span className="text-xs">
                  {hoveredLocation.availableChargers}/{hoveredLocation.totalChargers} available
                </span>
              </div>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>

      {/* Map controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-20">
        <Button
          variant="secondary"
          size="icon"
          className="h-9 w-9 shadow-md bg-background"
          onClick={handleZoomIn}
        >
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button
          variant="secondary"
          size="icon"
          className="h-9 w-9 shadow-md bg-background"
          onClick={handleZoomOut}
        >
          <ZoomOut className="h-4 w-4" />
        </Button>
        <Button
          variant="secondary"
          size="icon"
          className="h-9 w-9 shadow-md bg-background"
          onClick={handleLocateUser}
          title="Find my location"
        >
          <Navigation className="h-4 w-4" />
        </Button>
      </div>

      {/* Stats overlay */}
      <div className="absolute top-4 left-4 bg-background/90 backdrop-blur-sm px-3 py-2 rounded-lg shadow-md border border-border/50 z-20">
        <div className="text-xs text-muted-foreground">
          <span className="font-medium text-foreground">{locations.length}</span> locations
        </div>
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 right-4 bg-background/90 backdrop-blur-sm px-4 py-3 rounded-lg shadow-md border border-border/50 z-20">
        <div className="flex flex-col gap-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-green-500" />
            <span className="text-muted-foreground">Available</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-gray-500" />
            <span className="text-muted-foreground">All in use</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-amber-500" />
            <span className="text-muted-foreground">Under repair</span>
          </div>
          {userLocation && (
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-500" />
              <span className="text-muted-foreground">You</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
