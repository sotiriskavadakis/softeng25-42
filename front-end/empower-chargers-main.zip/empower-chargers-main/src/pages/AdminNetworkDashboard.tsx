import { useState, useMemo } from "react";
import { TopNav } from "@/components/layout/TopNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAdminStats } from "@/hooks/useAdminStats";
import { useIsAdmin } from "@/hooks/useUserRole";
import { useChargers } from "@/hooks/useChargers";
import {
  Activity,
  Zap,
  DollarSign,
  Users,
  AlertTriangle,
  TrendingUp,
  MapPin,
  Gauge,
  BarChart3,
  Calendar,
  Download,
  Shield,
  Loader2,
} from "lucide-react";
import { motion } from "framer-motion";
import { Navigate } from "react-router-dom";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from "recharts";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 15 },
  visible: { opacity: 1, y: 0 },
};

const COLORS = ["hsl(160, 85%, 40%)", "hsl(250, 85%, 60%)", "hsl(45, 100%, 50%)", "hsl(0, 80%, 60%)", "hsl(220, 12%, 50%)"];

const STATUS_COLORS: Record<string, string> = {
  AVAILABLE: "hsl(160, 85%, 40%)",
  OCCUPIED: "hsl(250, 85%, 60%)",
  RESERVED: "hsl(45, 100%, 50%)",
  FAULTED: "hsl(0, 80%, 60%)",
  OFFLINE: "hsl(220, 12%, 50%)",
};

export default function AdminNetworkDashboard() {
  const { isAdmin, isLoading: isRoleLoading } = useIsAdmin();
  const [dateRange] = useState({
    from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    to: new Date(),
  });

  const { data: stats, isLoading: isStatsLoading } = useAdminStats(dateRange);
  const { data: chargers = [] } = useChargers();

  // Redirect non-admins
  if (!isRoleLoading && !isAdmin) {
    return <Navigate to="/" replace />;
  }

  if (isRoleLoading || isStatsLoading) {
    return (
      <div className="min-h-screen bg-background">
        <TopNav />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  const kpiCards = [
    {
      title: "Total Sessions",
      value: stats?.totalSessions.toLocaleString() || "0",
      icon: Activity,
      trend: "+12%",
      trendUp: true,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "Total Revenue",
      value: `€${stats?.totalRevenue.toFixed(2) || "0.00"}`,
      icon: DollarSign,
      trend: "+8%",
      trendUp: true,
      color: "text-success",
      bgColor: "bg-success/10",
    },
    {
      title: "Energy Delivered",
      value: `${stats?.totalKwh.toFixed(0) || "0"} kWh`,
      icon: Zap,
      trend: "+15%",
      trendUp: true,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      title: "Utilization Rate",
      value: `${stats?.utilizationRate || 0}%`,
      icon: Gauge,
      trend: "+5%",
      trendUp: true,
      color: "text-warning",
      bgColor: "bg-warning/10",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <TopNav />

      <motion.main
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto"
      >
        {/* Header */}
        <motion.div variants={itemVariants} className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Shield className="h-6 w-6 text-primary" />
              <h1 className="text-2xl font-bold">Network Dashboard</h1>
              <Badge variant="outline" className="ml-2 border-primary/30 text-primary">
                Admin
              </Badge>
            </div>
            <p className="text-muted-foreground">
              Overview of network performance • Last 30 days
            </p>
          </div>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export Report
          </Button>
        </motion.div>

        {/* KPI Cards */}
        <motion.div variants={itemVariants} className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {kpiCards.map((kpi) => (
            <Card key={kpi.title} className="relative overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{kpi.title}</p>
                    <p className="text-2xl font-bold mt-1">{kpi.value}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <TrendingUp className={`h-3 w-3 ${kpi.trendUp ? "text-success" : "text-destructive"}`} />
                      <span className={`text-xs ${kpi.trendUp ? "text-success" : "text-destructive"}`}>
                        {kpi.trend}
                      </span>
                      <span className="text-xs text-muted-foreground">vs last period</span>
                    </div>
                  </div>
                  <div className={`p-2 rounded-lg ${kpi.bgColor}`}>
                    <kpi.icon className={`h-5 w-5 ${kpi.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        {/* Tabs for different views */}
        <motion.div variants={itemVariants}>
          <Tabs defaultValue="system" className="space-y-4">
            <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
              <TabsTrigger value="system" className="gap-2">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden sm:inline">System-wide</span>
              </TabsTrigger>
              <TabsTrigger value="stations" className="gap-2">
                <MapPin className="h-4 w-4" />
                <span className="hidden sm:inline">Per Station</span>
              </TabsTrigger>
              <TabsTrigger value="chargers" className="gap-2">
                <Zap className="h-4 w-4" />
                <span className="hidden sm:inline">Per Charger</span>
              </TabsTrigger>
              <TabsTrigger value="alerts" className="gap-2">
                <AlertTriangle className="h-4 w-4" />
                <span className="hidden sm:inline">Alerts</span>
              </TabsTrigger>
            </TabsList>

            {/* System-wide Tab */}
            <TabsContent value="system" className="space-y-4">
              <div className="grid lg:grid-cols-2 gap-4">
                {/* Revenue Chart */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-primary" />
                      Revenue & Sessions Over Time
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={stats?.revenueByDay || []}>
                          <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                          <XAxis
                            dataKey="date"
                            tickFormatter={(value) => new Date(value).toLocaleDateString("en", { month: "short", day: "numeric" })}
                            className="text-xs"
                          />
                          <YAxis className="text-xs" />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                            }}
                          />
                          <Area
                            type="monotone"
                            dataKey="revenue"
                            stroke="hsl(160, 85%, 40%)"
                            fill="hsl(160, 85%, 40% / 0.2)"
                            name="Revenue (€)"
                          />
                          <Area
                            type="monotone"
                            dataKey="sessions"
                            stroke="hsl(250, 85%, 60%)"
                            fill="hsl(250, 85%, 60% / 0.2)"
                            name="Sessions"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                {/* Charger Status Pie */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Gauge className="h-4 w-4 text-primary" />
                      Charger Status Distribution
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={stats?.chargerStatusBreakdown || []}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={100}
                            paddingAngle={2}
                            dataKey="count"
                            nameKey="status"
                            label={({ status, count }) => `${status}: ${count}`}
                          >
                            {stats?.chargerStatusBreakdown.map((entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={STATUS_COLORS[entry.status] || COLORS[index % COLORS.length]}
                              />
                            ))}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Per Station Tab */}
            <TabsContent value="stations" className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-primary" />
                    Top Performing Locations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[350px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={stats?.topLocations || []} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                        <XAxis type="number" className="text-xs" />
                        <YAxis dataKey="name" type="category" width={150} className="text-xs" />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "hsl(var(--card))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "8px",
                          }}
                        />
                        <Legend />
                        <Bar dataKey="sessions" fill="hsl(250, 85%, 60%)" name="Sessions" radius={[0, 4, 4, 0]} />
                        <Bar dataKey="revenue" fill="hsl(160, 85%, 40%)" name="Revenue (€)" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Per Charger Tab */}
            <TabsContent value="chargers" className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Zap className="h-4 w-4 text-primary" />
                    Charger Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-2 font-medium">Charger ID</th>
                          <th className="text-left py-3 px-2 font-medium">Location</th>
                          <th className="text-left py-3 px-2 font-medium">Type</th>
                          <th className="text-left py-3 px-2 font-medium">Power</th>
                          <th className="text-left py-3 px-2 font-medium">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {chargers.slice(0, 10).map((charger) => (
                          <tr key={charger.chargerId} className="border-b border-border/50 hover:bg-muted/50">
                            <td className="py-3 px-2 font-mono text-xs">#{charger.chargerId}</td>
                            <td className="py-3 px-2">{charger.locationName}</td>
                            <td className="py-3 px-2">
                              <Badge variant="outline" className="text-xs">
                                {charger.typeName}
                              </Badge>
                            </td>
                            <td className="py-3 px-2">{charger.maxPowerKw} kW</td>
                            <td className="py-3 px-2">
                              <Badge
                                className={`text-xs ${
                                  charger.status === "available"
                                    ? "bg-success/10 text-success border-success/20"
                                    : charger.status === "occupied"
                                    ? "bg-primary/10 text-primary border-primary/20"
                                    : charger.status === "faulted"
                                    ? "bg-destructive/10 text-destructive border-destructive/20"
                                    : "bg-muted text-muted-foreground"
                                }`}
                              >
                                {charger.status}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Alerts Tab */}
            <TabsContent value="alerts" className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-warning" />
                    System Alerts & Faults
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {chargers
                      .filter((c) => c.status === "faulted" || c.status === "offline")
                      .slice(0, 5)
                      .map((charger) => (
                        <div
                          key={charger.chargerId}
                          className={`flex items-center justify-between p-3 rounded-lg border ${
                            charger.status === "faulted"
                              ? "bg-destructive/5 border-destructive/20"
                              : "bg-muted/50 border-border"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className={`p-2 rounded-lg ${
                                charger.status === "faulted" ? "bg-destructive/10" : "bg-muted"
                              }`}
                            >
                              <AlertTriangle
                                className={`h-4 w-4 ${
                                  charger.status === "faulted" ? "text-destructive" : "text-muted-foreground"
                                }`}
                              />
                            </div>
                            <div>
                              <p className="font-medium text-sm">
                                Charger #{charger.chargerId} - {charger.status.toUpperCase()}
                              </p>
                              <p className="text-xs text-muted-foreground">{charger.locationName}</p>
                            </div>
                          </div>
                          <Badge
                            variant="outline"
                            className={
                              charger.status === "faulted"
                                ? "border-destructive/30 text-destructive"
                                : "border-muted-foreground/30"
                            }
                          >
                            Needs Attention
                          </Badge>
                        </div>
                      ))}
                    {chargers.filter((c) => c.status === "faulted" || c.status === "offline").length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        <AlertTriangle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                        <p>No active alerts</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </motion.main>
    </div>
  );
}
