import { useState } from "react";
import { TopNav } from "@/components/layout/TopNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  User, 
  Mail, 
  Phone, 
  Car, 
  CreditCard, 
  Bell,
  Shield,
  ChevronRight,
  Edit2,
  Zap,
  Leaf,
  Check,
  Sun,
  Moon,
  Monitor
} from "lucide-react";
import { motion } from "framer-motion";
import { useTheme } from "next-themes";
import { useUserProfile, useUpdateProfile, useSavedCards } from "@/hooks/useUserProfile";
import { useUserStatsData } from "@/hooks/useUserStats";
import { toast } from "@/hooks/use-toast";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 15 },
  visible: { opacity: 1, y: 0 }
};

export default function ProfilePage() {
  const { theme, setTheme } = useTheme();
  const { data: profile, isLoading: profileLoading } = useUserProfile();
  const { data: statsData, isLoading: statsLoading } = useUserStatsData();
  const { data: savedCards = [], isLoading: cardsLoading } = useSavedCards();
  const updateProfile = useUpdateProfile();
  
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
  });
  const [isEditing, setIsEditing] = useState(false);

  // Initialize form when profile loads
  useState(() => {
    if (profile) {
      setFormData({
        firstName: profile.firstName || "",
        lastName: profile.lastName || "",
        email: profile.email || "",
        phone: "",
      });
    }
  });

  const handleSave = async () => {
    try {
      await updateProfile.mutateAsync({
        firstName: formData.firstName,
        lastName: formData.lastName,
      });
      toast({
        title: "Profile Updated",
        description: "Your profile has been saved successfully.",
      });
      setIsEditing(false);
    } catch {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    }
  };

  const displayName = profile 
    ? `${profile.firstName || ""} ${profile.lastName || ""}`.trim() || profile.username || "User"
    : "User";
  
  const initials = displayName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  const stats = statsData?.stats;
  const isLoading = profileLoading || statsLoading;

  return (
    <div className="min-h-screen bg-background">
      <TopNav />
      
      <motion.main 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="p-4 md:p-6 space-y-5 max-w-2xl mx-auto"
      >
        {/* Header */}
        <motion.div variants={itemVariants}>
          <h1 className="text-2xl font-bold">Profile</h1>
          <p className="text-muted-foreground">Manage your account settings</p>
        </motion.div>

        {/* Profile Card */}
        <motion.div variants={itemVariants}>
          <Card className="overflow-hidden">
            <div className="h-20 bg-gradient-to-r from-primary/20 via-primary/10 to-accent" />
            <CardContent className="pt-0 -mt-10">
              {isLoading ? (
                <div className="flex items-end gap-4">
                  <Skeleton className="w-20 h-20 rounded-2xl" />
                  <div className="flex-1 pb-1">
                    <Skeleton className="h-6 w-32 mb-1" />
                    <Skeleton className="h-4 w-48" />
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-end gap-4">
                    <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-primary-glow flex items-center justify-center text-primary-foreground text-2xl font-bold shadow-lg border-4 border-background">
                      {initials}
                    </div>
                    <div className="flex-1 pb-1">
                      <div className="flex items-center gap-2">
                        <h2 className="text-xl font-bold">{displayName}</h2>
                        {profile && (
                          <Badge className="bg-success/10 text-success border-success/20 gap-1">
                            <Check className="h-3 w-3" />
                            Verified
                          </Badge>
                        )}
                      </div>
                      <p className="text-muted-foreground text-sm">{profile?.email}</p>
                    </div>
                    <Button variant="outline" size="sm" className="gap-1.5 mb-1" onClick={() => setIsEditing(!isEditing)}>
                      <Edit2 className="h-3.5 w-3.5" />
                      Edit
                    </Button>
                  </div>
                  
                  {/* Quick Stats */}
                  <div className="grid grid-cols-3 gap-3 mt-5 pt-5 border-t border-border">
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 text-primary mb-1">
                        <Zap className="h-4 w-4" />
                      </div>
                      <p className="text-lg font-bold">{stats?.totalSessions || 0}</p>
                      <p className="text-xs text-muted-foreground">Sessions</p>
                    </div>
                    <div className="text-center border-x border-border">
                      <div className="flex items-center justify-center gap-1 text-primary mb-1">
                        <Zap className="h-4 w-4" />
                      </div>
                      <p className="text-lg font-bold">{Math.round(stats?.totalKwh || 0).toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">kWh Used</p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 text-success mb-1">
                        <Leaf className="h-4 w-4" />
                      </div>
                      <p className="text-lg font-bold">{((stats?.co2Saved || 0) / 1000).toFixed(1)}t</p>
                      <p className="text-xs text-muted-foreground">CO₂ Saved</p>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Personal Info */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-base flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-primary/10">
                  <User className="h-4 w-4 text-primary" />
                </div>
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {profileLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName" className="text-sm">First Name</Label>
                      <Input 
                        id="firstName" 
                        value={isEditing ? formData.firstName : (profile?.firstName || "")}
                        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                        disabled={!isEditing}
                        className="h-10" 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName" className="text-sm">Last Name</Label>
                      <Input 
                        id="lastName" 
                        value={isEditing ? formData.lastName : (profile?.lastName || "")}
                        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                        disabled={!isEditing}
                        className="h-10" 
                      />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="email" className="text-sm">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input 
                          id="email" 
                          value={profile?.email || ""} 
                          disabled
                          className="pl-10 h-10" 
                        />
                      </div>
                    </div>
                  </div>
                  {isEditing && (
                    <Button 
                      className="gap-2" 
                      onClick={handleSave}
                      disabled={updateProfile.isPending}
                    >
                      <Check className="h-4 w-4" />
                      {updateProfile.isPending ? "Saving..." : "Save Changes"}
                    </Button>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Vehicle Info */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-base flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-primary/10">
                  <Car className="h-4 w-4 text-primary" />
                </div>
                My Vehicle
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between p-4 bg-muted/50 rounded-xl border border-border">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                    <Car className="h-7 w-7 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">Electric Vehicle</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <Badge variant="outline" className="text-xs">EV</Badge>
                      <Badge variant="outline" className="text-xs">CCS</Badge>
                    </div>
                  </div>
                </div>
                <Button variant="ghost" size="sm" className="gap-1.5">
                  <Edit2 className="h-3.5 w-3.5" />
                  Edit
                </Button>
              </div>
              <Button variant="outline" className="w-full mt-3 gap-2 border-dashed">
                <Car className="h-4 w-4" />
                Add Another Vehicle
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Notifications */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-base flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-primary/10">
                  <Bell className="h-4 w-4 text-primary" />
                </div>
                Notifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: "Charging complete alerts", description: "Get notified when your session ends", enabled: true },
                { label: "Price drop alerts", description: "Know when electricity rates are low", enabled: true },
                { label: "Reservation reminders", description: "15 min before your reservation starts", enabled: false },
              ].map((item, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-sm">{item.label}</p>
                    <p className="text-xs text-muted-foreground">{item.description}</p>
                  </div>
                  <Switch defaultChecked={item.enabled} />
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        {/* Appearance */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-base flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-primary/10">
                  <Sun className="h-4 w-4 text-primary" />
                </div>
                Appearance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label className="text-sm">Theme</Label>
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant={theme === "light" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setTheme("light")}
                    className="gap-2"
                  >
                    <Sun className="h-4 w-4" />
                    Light
                  </Button>
                  <Button
                    variant={theme === "dark" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setTheme("dark")}
                    className="gap-2"
                  >
                    <Moon className="h-4 w-4" />
                    Dark
                  </Button>
                  <Button
                    variant={theme === "system" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setTheme("system")}
                    className="gap-2"
                  >
                    <Monitor className="h-4 w-4" />
                    System
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Settings Links */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardContent className="pt-5 space-y-1">
              {[
                { 
                  icon: CreditCard, 
                  label: "Payment Methods", 
                  badge: cardsLoading ? "..." : `${savedCards.length} card${savedCards.length !== 1 ? "s" : ""}`, 
                  color: "text-primary" 
                },
                { icon: Shield, label: "Privacy & Security", color: "text-primary" },
              ].map(({ icon: Icon, label, badge, color }) => (
                <button
                  key={label}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-muted/50 transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-muted group-hover:bg-background transition-colors">
                      <Icon className={`h-4 w-4 ${color}`} />
                    </div>
                    <span className="font-medium text-sm">{label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {badge && (
                      <Badge variant="secondary" className="text-xs">{badge}</Badge>
                    )}
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                  </div>
                </button>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        {/* Danger Zone */}
        <motion.div variants={itemVariants}>
          <Card className="border-destructive/20">
            <CardContent className="pt-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-sm">Delete Account</p>
                  <p className="text-xs text-muted-foreground">Permanently delete your account and all data</p>
                </div>
                <Button variant="outline" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10 border-destructive/30">
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.main>
    </div>
  );
}
