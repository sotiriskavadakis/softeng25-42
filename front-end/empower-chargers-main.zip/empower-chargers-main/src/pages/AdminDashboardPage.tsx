import { useState } from "react";
import { TopNav } from "@/components/layout/TopNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Download, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

type ViewTab = "system" | "station" | "charger" | "area";

// Mock trend data
const trendData = [
  { date: "1-1", revenue: 80000, kwh: 320000 },
  { date: "3-5", revenue: 120000, kwh: 350000 },
  { date: "5-7", revenue: 150000, kwh: 380000 },
  { date: "7-9", revenue: 180000, kwh: 390000 },
  { date: "11-13", revenue: 220000, kwh: 410000 },
  { date: "13-13", revenue: 280000, kwh: 420000 },
  { date: "15-17", revenue: 350000, kwh: 430000 },
  { date: "17-19", revenue: 420000, kwh: 440000 },
  { date: "19-23", revenue: 480000, kwh: 450000 },
  { date: "21-25", revenue: 520000, kwh: 460000 },
  { date: "21-27", revenue: 540000, kwh: 470000 },
  { date: "19-30", revenue: 560000, kwh: 480000 },
];

// Mock peak hours data
const peakHoursData = Array.from({ length: 22 }, (_, i) => ({
  hour: `${String(i + 1).padStart(2, "0")}:00`,
  usage: Math.floor(Math.random() * 50000) + (i >= 9 && i <= 18 ? 30000 : 5000),
}));

// Mock areas data
const areasData = [
  { name: "Downtown", percentage: 40 },
  { name: "Airport", percentage: 25 },
  { name: "Suburb A", percentage: 20 },
  { name: "Suburb B", percentage: 15 },
];

export default function AdminDashboardPage() {
  const [activeView, setActiveView] = useState<ViewTab>("system");
  const [dateRange, setDateRange] = useState("last30");
  const [area, setArea] = useState("all");
  const [stationSearch, setStationSearch] = useState("");

  const viewTabs: { key: ViewTab; label: string }[] = [
    { key: "system", label: "System-wide" },
    { key: "station", label: "Per Station" },
    { key: "charger", label: "Per Charger" },
    { key: "area", label: "Per Area" },
  ];

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Custom Admin Header */}
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold">ADMIN DASHBOARD</h1>
          <div className="flex items-center gap-2">
            {["Overview", "Stations", "Users", "Statistics", "Account"].map((tab, idx) => (
              <Button
                key={tab}
                variant={tab === "Statistics" ? "default" : "outline"}
                className="min-w-[100px]"
              >
                {tab}
              </Button>
            ))}
          </div>
        </div>
      </header>

      <main className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Statistics Title */}
        <h2 className="text-xl font-semibold">Statistics</h2>

        {/* Filters Row */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Date Range</span>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="last30">Last 30 Days</SelectItem>
                <SelectItem value="last7">Last 7 Days</SelectItem>
                <SelectItem value="last90">Last 90 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Area</span>
            <Select value={area} onValueChange={setArea}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Areas</SelectItem>
                <SelectItem value="downtown">Downtown</SelectItem>
                <SelectItem value="airport">Airport</SelectItem>
                <SelectItem value="suburb">Suburbs</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Station</span>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="All Stations"
                value={stationSearch}
                onChange={(e) => setStationSearch(e.target.value)}
                className="pl-9 w-40"
              />
            </div>
          </div>

          <Button variant="outline" className="ml-auto">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>

        {/* View Tabs */}
        <div className="flex gap-6 border-b border-border">
          {viewTabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveView(tab.key)}
              className={cn(
                "pb-3 font-medium transition-colors relative",
                activeView === tab.key
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {tab.label}
              {activeView === tab.key && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-foreground" />
              )}
            </button>
          ))}
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-sm text-muted-foreground mb-1">Total Revenue</p>
              <p className="text-3xl font-bold">€124,500</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-sm text-muted-foreground mb-1">Total kWh</p>
              <p className="text-3xl font-bold">450,000</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-sm text-muted-foreground mb-1">Total Sessions</p>
              <p className="text-3xl font-bold">15,200</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-sm text-muted-foreground mb-1">Avg. Session Duration</p>
              <p className="text-3xl font-bold">45m</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid lg:grid-cols-5 gap-4">
          {/* Revenue & kWh Trend */}
          <Card className="lg:col-span-3">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Revenue & kWh Trend (Last 30 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                    <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="revenue" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={2} 
                      dot={false}
                      name="Revenue"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="kwh" 
                      stroke="hsl(var(--muted-foreground))" 
                      strokeWidth={2} 
                      dot={false}
                      name="kWh"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Peak Hours */}
          <Card className="lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Peak Hours</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={peakHoursData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="hour" tick={{ fontSize: 9 }} stroke="hsl(var(--muted-foreground))" />
                    <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                    <Tooltip />
                    <Bar dataKey="usage" fill="hsl(var(--primary))" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bottom Row */}
        <div className="grid lg:grid-cols-2 gap-4">
          {/* Utilization Overview */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Utilization Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center py-8">
                <div className="relative w-40 h-40">
                  {/* Circular progress background */}
                  <svg className="w-full h-full transform -rotate-90">
                    <circle
                      cx="80"
                      cy="80"
                      r="70"
                      stroke="hsl(var(--muted))"
                      strokeWidth="12"
                      fill="none"
                    />
                    <circle
                      cx="80"
                      cy="80"
                      r="70"
                      stroke="hsl(var(--primary))"
                      strokeWidth="12"
                      fill="none"
                      strokeDasharray={`${2 * Math.PI * 70 * 0.75} ${2 * Math.PI * 70}`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-4xl font-bold">75%</span>
                    <span className="text-sm text-muted-foreground">Active</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Most Used Areas */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Most Used Areas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {areasData.map((area) => (
                <div key={area.name} className="flex items-center gap-3">
                  <span className="text-sm w-28">{area.name} ({area.percentage}%)</span>
                  <div className="flex-1 bg-muted rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all"
                      style={{ width: `${area.percentage * 2}%` }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
