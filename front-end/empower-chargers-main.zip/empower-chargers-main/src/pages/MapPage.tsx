import { useState, useMemo } from "react";
import { TopNav } from "@/components/layout/TopNav";
import { Button } from "@/components/ui/button";
import { SearchFilters, FilterState } from "@/components/map/SearchFilters";
import { GoogleMapComponent } from "@/components/map/GoogleMap";
import { LocationPopup } from "@/components/map/LocationPopup";
import { HealthCheckWidget } from "@/components/map/HealthCheckWidget";
import { ChargingSessionOverlay } from "@/components/session";
import { 
  useChargingPoints, 
  LocationWithChargers, 
  ChargerInfo,
  getErrorMessage 
} from "@/hooks/useChargingPoints";
import { AnimatePresence } from "framer-motion";
import { toast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { Loader2, SearchX, RotateCcw, MapPin, WifiOff, RefreshCw } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export default function MapPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: locations = [], isLoading, error, isRefetching, refetch } = useChargingPoints();
  const [selectedLocation, setSelectedLocation] = useState<LocationWithChargers | null>(null);
  const [selectedCharger, setSelectedCharger] = useState<ChargerInfo | null>(null);
  const [isCharging, setIsCharging] = useState(false);
  const [filters, setFilters] = useState<FilterState | null>(null);

  const handleRetry = () => {
    refetch();
    toast({
      title: "Retrying...",
      description: "Attempting to reconnect to the server.",
    });
  };

  // Filter locations based on current filters (client-side filtering)
  const filteredLocations = useMemo(() => {
    if (!filters || !filters.status) return locations;

    return locations.filter((location) => {
      // Filter by status - check if any charger at location matches selected statuses
      if (filters.status && filters.status.length > 0) {
        const locationStatus = location.status || "AVAILABLE";
        if (!filters.status.includes(locationStatus)) return false;
      }

      // Filter by power range - check chargers' power
      if (filters.powerRange && (filters.powerRange[0] > 2 || filters.powerRange[1] < 300)) {
        const hasChargerInRange = location.chargers?.some(charger => 
          charger.maxPowerKw >= filters.powerRange[0] && 
          charger.maxPowerKw <= filters.powerRange[1]
        );
        if (!hasChargerInRange) return false;
      }

      // Filter by under repair
      if (filters.hideUnderRepair && location.underRepair) {
        return false;
      }

      // Filter by coming soon
      if (filters.hideComingSoon && location.comingSoon) {
        return false;
      }

      return true;
    });
  }, [locations, filters]);

  const handleSearch = (newFilters: FilterState) => {
    setFilters(newFilters);
    
    // Calculate filtered count for toast
    const count = locations.filter((location) => {
      if (newFilters.status.length > 0) {
        const locationStatus = location.status || "AVAILABLE";
        if (!newFilters.status.includes(locationStatus)) return false;
      }
      if (newFilters.powerRange[0] > 2 || newFilters.powerRange[1] < 300) {
        const hasChargerInRange = location.chargers?.some(charger => 
          charger.maxPowerKw >= newFilters.powerRange[0] && 
          charger.maxPowerKw <= newFilters.powerRange[1]
        );
        if (!hasChargerInRange) return false;
      }
      if (newFilters.hideUnderRepair && location.underRepair) return false;
      if (newFilters.hideComingSoon && location.comingSoon) return false;
      return true;
    }).length;

    if (count === 0) {
      toast({
        title: "No Locations Found",
        description: "Try adjusting your filters to find charging locations.",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Filters Applied",
        description: `Found ${count} location${count !== 1 ? 's' : ''} with ${filteredLocations.reduce((sum, l) => sum + l.availableChargers, 0)} available chargers`,
      });
    }
  };

  const handleClearFilters = () => {
    setFilters(null);
    toast({
      title: "Filters Reset",
      description: `Showing all ${locations.length} locations`,
    });
  };

  const handleLocationClick = (location: LocationWithChargers) => {
    setSelectedLocation(location);
    setSelectedCharger(null);
  };

  const handleClosePopup = () => {
    setSelectedLocation(null);
    setSelectedCharger(null);
  };

  const handleNavigate = () => {
    if (selectedLocation) {
      // Open Google Maps with directions
      const url = `https://www.google.com/maps/dir/?api=1&destination=${selectedLocation.latitude},${selectedLocation.longitude}`;
      window.open(url, '_blank');
      toast({
        title: "Navigation",
        description: "Opening Google Maps...",
      });
    }
  };

  const handleSelectCharger = (charger: ChargerInfo) => {
    setSelectedCharger(charger);
    setIsCharging(true);
    toast({
      title: "Charging Started",
      description: `Now charging at ${selectedLocation?.name}`,
    });
  };

  const handleStopCharging = () => {
    setIsCharging(false);
    setSelectedCharger(null);
    toast({
      title: "Charging Complete",
      description: "Your session has ended. Check your stats!",
    });
    navigate("/sessions");
  };

  // Calculate total stats
  const totalAvailable = useMemo(() => 
    filteredLocations.reduce((sum, loc) => sum + loc.availableChargers, 0),
    [filteredLocations]
  );

  return (
    <div className="min-h-screen bg-background">
      <TopNav />

      <main className="p-4 md:p-6">
        <div className="max-w-7xl mx-auto">
          {/* Quick stats bar */}
          <div className="flex items-center gap-4 mb-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" />
              <span><strong className="text-foreground">{filteredLocations.length}</strong> locations</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-success" />
              <span><strong className="text-foreground">{totalAvailable}</strong> chargers available</span>
            </div>
          </div>

          <div className="flex flex-col lg:flex-row gap-6">
            {/* Map Area */}
            <div className="flex-1 relative">
              <div className="rounded-xl overflow-hidden border border-border shadow-sm h-[500px] lg:h-[600px]">
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center h-full bg-muted/50 gap-3">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    <p className="text-sm text-muted-foreground">Loading charging stations...</p>
                  </div>
                ) : error ? (
                  <div className="flex flex-col items-center justify-center h-full bg-muted/50 gap-4 p-6 text-center">
                    <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center">
                      <WifiOff className="h-8 w-8 text-destructive" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg text-foreground">Unable to load charging stations</h3>
                      <p className="text-muted-foreground text-sm mt-1 max-w-sm">
                        {getErrorMessage(error)}
                      </p>
                    </div>
                    <Button 
                      variant="outline" 
                      onClick={handleRetry} 
                      className="gap-2"
                      disabled={isRefetching}
                    >
                      {isRefetching ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <RefreshCw className="h-4 w-4" />
                      )}
                      {isRefetching ? "Retrying..." : "Try Again"}
                    </Button>
                  </div>
                ) : locations.length === 0 && !filters ? (
                  <div className="flex flex-col items-center justify-center h-full bg-muted/50 gap-4 p-6 text-center">
                    <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                      <MapPin className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg text-foreground">No charging stations</h3>
                      <p className="text-muted-foreground text-sm mt-1">
                        There are no charging stations in the database yet.
                      </p>
                    </div>
                  </div>
                ) : filteredLocations.length === 0 && filters ? (
                  <div className="flex flex-col items-center justify-center h-full bg-muted/50 gap-4 p-6 text-center">
                    <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                      <SearchX className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg text-foreground">No locations found</h3>
                      <p className="text-muted-foreground text-sm mt-1">
                        No charging stations match your filters.
                      </p>
                    </div>
                    <Button variant="outline" onClick={handleClearFilters} className="gap-2">
                      <RotateCcw className="h-4 w-4" />
                      Clear Filters
                    </Button>
                  </div>
                ) : (
                  <GoogleMapComponent 
                    locations={filteredLocations} 
                    onLocationClick={handleLocationClick}
                    selectedLocationId={selectedLocation?.locationId}
                  />
                )}
              </div>

              {/* Location Popup - appears over the map */}
              <AnimatePresence>
                {selectedLocation && !isCharging && (
                  <LocationPopup
                    location={selectedLocation}
                    onClose={handleClosePopup}
                    onNavigate={handleNavigate}
                    onSelectCharger={handleSelectCharger}
                  />
                )}
              </AnimatePresence>
            </div>

            {/* Search Filters Sidebar */}
            <div className="w-full lg:w-80 shrink-0 space-y-4">
              <HealthCheckWidget />
              <SearchFilters onSearch={handleSearch} onClear={handleClearFilters} />
            </div>
          </div>
        </div>
      </main>

      {/* Charging Session Overlay */}
      <AnimatePresence>
        {isCharging && selectedLocation && selectedCharger && (
          <ChargingSessionOverlay
            chargerName={`${selectedLocation.name} - ${selectedCharger.typeName} #${selectedCharger.chargerId.toString().slice(-4)}`}
            onStop={handleStopCharging}
            onClose={() => setIsCharging(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
