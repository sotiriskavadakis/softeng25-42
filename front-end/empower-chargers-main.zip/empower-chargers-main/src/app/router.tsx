import { Routes, Route } from "react-router-dom";
import MapPage from "@/pages/MapPage";
import UserStatsPage from "@/pages/UserStatsPage";
import ProfilePage from "@/pages/ProfilePage";
import AdminDashboardPage from "@/pages/AdminDashboardPage";
import AdminNetworkDashboard from "@/pages/AdminNetworkDashboard";
import SessionsPage from "@/pages/SessionsPage";
import DataDictionaryPage from "@/pages/DataDictionaryPage";
import AuthPage from "@/pages/AuthPage";
import NotFound from "@/pages/NotFound";
import { ProtectedRoute } from "@/components/auth";

export function AppRouter() {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<MapPage />} />
      <Route path="/auth" element={<AuthPage />} />
      
      {/* Protected routes - require authentication */}
      <Route path="/stats" element={
        <ProtectedRoute>
          <UserStatsPage />
        </ProtectedRoute>
      } />
      <Route path="/profile" element={
        <ProtectedRoute>
          <ProfilePage />
        </ProtectedRoute>
      } />
      <Route path="/sessions" element={
        <ProtectedRoute>
          <SessionsPage />
        </ProtectedRoute>
      } />
      <Route path="/admin" element={
        <ProtectedRoute>
          <AdminDashboardPage />
        </ProtectedRoute>
      } />
      <Route path="/admin/network" element={
        <ProtectedRoute>
          <AdminNetworkDashboard />
        </ProtectedRoute>
      } />
      
      {/* Dev routes */}
      <Route path="/dev/data-dictionary" element={<DataDictionaryPage />} />
      
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
