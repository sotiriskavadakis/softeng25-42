export type UserRole = "user" | "admin" | "manager";

export interface User {
  userId: string;
  email: string;
  username: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  createdAt: Date;
}

// User Statistics matching SRS Use Case 3
export interface UserStats {
  // Summary metrics
  totalSessions: number;
  totalKwh: number;
  totalSpent: number;
  co2Saved: number;
  averageSessionDuration: number; // in minutes
  favoriteLocation?: string;
  // Monthly breakdown for the last 6 months (analytical)
  monthlyUsage: MonthlyUsage[];
}

export interface MonthlyUsage {
  month: string;
  year: number;
  totalKwh: number;
  totalCost: number;
  sessionCount: number;
  averageCostPerKwh: number;
}

// Aggregated stats for periods > 6 months
export interface AggregatedStats {
  startDate: Date;
  endDate: Date;
  totalKwh: number;
  totalCost: number;
  sessionCount: number;
}

// Admin Statistics matching SRS Use Case 4
export interface AdminStats {
  // System-wide KPIs
  totalUsers: number;
  totalChargers: number;
  activeChargers: number;
  activeSessions: number;
  totalRevenue: number;
  totalKwh: number;
  // Utilization
  utilizationRate: number;
  peakHours: string[];
  // Alerts/Faults
  alerts: AdminAlert[];
}

export type AlertType = "error" | "warning" | "info";

export interface AdminAlert {
  id: string;
  type: AlertType;
  message: string;
  chargerId?: string;
  chargerName?: string;
  locationName?: string;
  timestamp: Date;
  resolved: boolean;
}

// Per-Area statistics
export interface AreaStats {
  regionName: string;
  countyName?: string;
  totalRevenue: number;
  totalKwh: number;
  sessionCount: number;
  chargerCount: number;
  utilizationRate: number;
}

// Per-Station statistics
export interface StationStats {
  stationId: string;
  locationName: string;
  utilizationRate: number;
  queueWaitTime: number; // in minutes
  totalRevenue: number;
  totalKwh: number;
  sessionCount: number;
  connectorAvailability: number; // percentage
}

// Per-Charger statistics (includes fault logs)
export interface ChargerStats {
  chargerId: string;
  chargerName: string;
  locationName: string;
  averageChargingSpeed: number; // kW
  averageSessionDuration: number; // minutes
  faultCount: number;
  uptime: number; // percentage
  faultLogs: FaultLog[];
}

export interface FaultLog {
  id: string;
  chargerId: string;
  timestamp: Date;
  errorCode: string;
  description: string;
  resolved: boolean;
  resolvedAt?: Date;
}

// Transaction History matching FR-07
export interface Transaction {
  transactionId: string;
  sessionId: string;
  userId: string;
  chargerId: string;
  chargerName: string;
  locationName: string;
  timestamp: Date;
  totalKwh: number;
  totalCost: number;
  paymentMethod: string;
  status: "completed" | "pending" | "failed" | "refunded";
}

// Saved payment methods
export interface SavedCard {
  cardId: string;
  userId: string;
  methodName: string;
  last4Digits: string;
  expiryMonth: number;
  expiryYear: number;
  isDefault: boolean;
}
