import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface UserStats {
  totalSessions: number;
  totalKwh: number;
  totalSpent: number;
  co2Saved: number;
  averageSessionDuration: number;
  favoriteLocation: string | null;
}

export interface MonthlyUsage {
  month: string;
  year: number;
  totalKwh: number;
  totalCost: number;
  sessionCount: number;
}

// CO2 saved per kWh (kg) - EV vs average gas car emissions
const CO2_SAVED_PER_KWH = 0.45;

export function useUserStatsData() {
  return useQuery({
    queryKey: ["user-stats"],
    queryFn: async (): Promise<{ stats: UserStats; monthlyUsage: MonthlyUsage[] }> => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        return {
          stats: {
            totalSessions: 0,
            totalKwh: 0,
            totalSpent: 0,
            co2Saved: 0,
            averageSessionDuration: 0,
            favoriteLocation: null,
          },
          monthlyUsage: [],
        };
      }

      // Fetch all user sessions with location info
      const { data: sessions, error } = await supabase
        .from("charging_sessions")
        .select(`
          session_id,
          start_time,
          end_time,
          total_kwh,
          total_cost,
          chargers (
            stations (
              locations (
                name
              )
            )
          )
        `)
        .eq("user_id", user.id);

      if (error) throw error;

      const allSessions = sessions || [];
      
      // Calculate totals
      const totalSessions = allSessions.length;
      const totalKwh = allSessions.reduce((sum, s) => sum + (Number(s.total_kwh) || 0), 0);
      const totalSpent = allSessions.reduce((sum, s) => sum + (Number(s.total_cost) || 0), 0);
      const co2Saved = totalKwh * CO2_SAVED_PER_KWH;

      // Calculate average session duration
      let totalDuration = 0;
      let sessionsWithDuration = 0;
      allSessions.forEach((s) => {
        if (s.start_time && s.end_time) {
          const start = new Date(s.start_time).getTime();
          const end = new Date(s.end_time).getTime();
          totalDuration += (end - start) / (1000 * 60); // in minutes
          sessionsWithDuration++;
        }
      });
      const averageSessionDuration = sessionsWithDuration > 0 
        ? Math.round(totalDuration / sessionsWithDuration) 
        : 0;

      // Find favorite location
      const locationCounts: Record<string, number> = {};
      allSessions.forEach((s) => {
        const locationName = s.chargers?.stations?.locations?.name;
        if (locationName) {
          locationCounts[locationName] = (locationCounts[locationName] || 0) + 1;
        }
      });
      const favoriteLocation = Object.entries(locationCounts)
        .sort((a, b) => b[1] - a[1])[0]?.[0] || null;

      // Calculate monthly usage for last 6 months
      const now = new Date();
      const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);
      
      const monthlyData: Record<string, MonthlyUsage> = {};
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

      allSessions
        .filter((s) => new Date(s.start_time) >= sixMonthsAgo)
        .forEach((s) => {
          const date = new Date(s.start_time);
          const key = `${date.getFullYear()}-${date.getMonth()}`;
          
          if (!monthlyData[key]) {
            monthlyData[key] = {
              month: monthNames[date.getMonth()],
              year: date.getFullYear(),
              totalKwh: 0,
              totalCost: 0,
              sessionCount: 0,
            };
          }
          
          monthlyData[key].totalKwh += Number(s.total_kwh) || 0;
          monthlyData[key].totalCost += Number(s.total_cost) || 0;
          monthlyData[key].sessionCount += 1;
        });

      // Sort monthly data chronologically
      const monthlyUsage = Object.values(monthlyData).sort((a, b) => {
        const aDate = new Date(a.year, monthNames.indexOf(a.month));
        const bDate = new Date(b.year, monthNames.indexOf(b.month));
        return aDate.getTime() - bDate.getTime();
      });

      return {
        stats: {
          totalSessions,
          totalKwh,
          totalSpent,
          co2Saved,
          averageSessionDuration,
          favoriteLocation,
        },
        monthlyUsage,
      };
    },
  });
}
