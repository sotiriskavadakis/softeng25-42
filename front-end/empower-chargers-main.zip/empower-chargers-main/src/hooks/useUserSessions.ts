import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface UserSession {
  sessionId: number;
  chargerId: number | null;
  startTime: string;
  endTime: string | null;
  totalKwh: number;
  totalCost: number;
  chargerName: string;
  locationName: string;
  locationAddress: string;
  connectorType: string;
  maxPowerKw: number;
  isActive: boolean;
}

export function useUserSessions() {
  return useQuery({
    queryKey: ["user-sessions"],
    queryFn: async (): Promise<UserSession[]> => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        return [];
      }

      const { data: sessions, error } = await supabase
        .from("charging_sessions")
        .select(`
          session_id,
          charger_id,
          start_time,
          end_time,
          total_kwh,
          total_cost,
          chargers (
            charger_id,
            max_power_kw,
            charger_types (
              name
            ),
            stations (
              locations (
                name,
                address
              )
            )
          )
        `)
        .eq("user_id", user.id)
        .order("start_time", { ascending: false });

      if (error) throw error;

      return (sessions || []).map((s) => {
        const charger = s.chargers;
        const location = charger?.stations?.locations;
        const chargerType = charger?.charger_types;

        return {
          sessionId: s.session_id,
          chargerId: s.charger_id,
          startTime: s.start_time,
          endTime: s.end_time,
          totalKwh: Number(s.total_kwh) || 0,
          totalCost: Number(s.total_cost) || 0,
          chargerName: `${chargerType?.name || "Charger"} #${s.charger_id}`,
          locationName: location?.name || "Unknown Location",
          locationAddress: location?.address || "",
          connectorType: chargerType?.name || "Unknown",
          maxPowerKw: Number(charger?.max_power_kw) || 0,
          isActive: !s.end_time,
        };
      });
    },
  });
}

export function useActiveSession() {
  return useQuery({
    queryKey: ["active-session"],
    queryFn: async (): Promise<UserSession | null> => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        return null;
      }

      const { data: sessions, error } = await supabase
        .from("charging_sessions")
        .select(`
          session_id,
          charger_id,
          start_time,
          end_time,
          total_kwh,
          total_cost,
          chargers (
            charger_id,
            max_power_kw,
            charger_types (
              name
            ),
            stations (
              locations (
                name,
                address
              )
            )
          )
        `)
        .eq("user_id", user.id)
        .is("end_time", null)
        .order("start_time", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      if (!sessions) return null;

      const charger = sessions.chargers;
      const location = charger?.stations?.locations;
      const chargerType = charger?.charger_types;

      return {
        sessionId: sessions.session_id,
        chargerId: sessions.charger_id,
        startTime: sessions.start_time,
        endTime: sessions.end_time,
        totalKwh: Number(sessions.total_kwh) || 0,
        totalCost: Number(sessions.total_cost) || 0,
        chargerName: `${chargerType?.name || "Charger"} #${sessions.charger_id}`,
        locationName: location?.name || "Unknown Location",
        locationAddress: location?.address || "",
        connectorType: chargerType?.name || "Unknown",
        maxPowerKw: Number(charger?.max_power_kw) || 0,
        isActive: true,
      };
    },
  });
}

export function useUserReservations() {
  return useQuery({
    queryKey: ["user-reservations"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        return [];
      }

      const { data: reservations, error } = await supabase
        .from("reservations")
        .select(`
          reservation_id,
          charger_id,
          start_time,
          duration_minutes,
          chargers (
            charger_id,
            max_power_kw,
            charger_types (
              name
            ),
            stations (
              locations (
                name,
                address
              )
            )
          )
        `)
        .eq("user_id", user.id)
        .gte("start_time", new Date().toISOString())
        .order("start_time", { ascending: true });

      if (error) throw error;

      return (reservations || []).map((r) => {
        const charger = r.chargers;
        const location = charger?.stations?.locations;
        const chargerType = charger?.charger_types;

        return {
          reservationId: r.reservation_id,
          chargerId: r.charger_id,
          startTime: r.start_time,
          durationMinutes: r.duration_minutes || 30,
          chargerName: `${chargerType?.name || "Charger"} #${r.charger_id}`,
          locationName: location?.name || "Unknown Location",
          locationAddress: location?.address || "",
          connectorType: chargerType?.name || "Unknown",
          maxPowerKw: Number(charger?.max_power_kw) || 0,
        };
      });
    },
  });
}
