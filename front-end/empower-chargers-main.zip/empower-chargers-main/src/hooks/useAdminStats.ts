import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface AdminStats {
  totalSessions: number;
  totalRevenue: number;
  totalKwh: number;
  activeChargers: number;
  faultedChargers: number;
  utilizationRate: number;
  sessionsByStatus: { status: string; count: number }[];
  revenueByDay: { date: string; revenue: number; sessions: number }[];
  topLocations: { name: string; sessions: number; revenue: number }[];
  chargerStatusBreakdown: { status: string; count: number }[];
}

export function useAdminStats(dateRange: { from: Date; to: Date }) {
  return useQuery({
    queryKey: ["admin-stats", dateRange.from.toISOString(), dateRange.to.toISOString()],
    queryFn: async (): Promise<AdminStats> => {
      // Fetch all charging sessions
      const { data: sessions, error: sessionsError } = await supabase
        .from("charging_sessions")
        .select("*")
        .gte("start_time", dateRange.from.toISOString())
        .lte("start_time", dateRange.to.toISOString());

      if (sessionsError) throw sessionsError;

      // Fetch all chargers with status
      const { data: chargers, error: chargersError } = await supabase
        .from("chargers")
        .select(`
          charger_id,
          status,
          max_power_kw,
          stations (
            location_id,
            locations (
              name
            )
          )
        `);

      if (chargersError) throw chargersError;

      // Calculate totals
      const totalSessions = sessions?.length || 0;
      const totalRevenue = sessions?.reduce((sum, s) => sum + (Number(s.total_cost) || 0), 0) || 0;
      const totalKwh = sessions?.reduce((sum, s) => sum + (Number(s.total_kwh) || 0), 0) || 0;

      // Charger status breakdown
      const statusCounts: Record<string, number> = {};
      chargers?.forEach((c) => {
        const status = c.status || "OFFLINE";
        statusCounts[status] = (statusCounts[status] || 0) + 1;
      });

      const chargerStatusBreakdown = Object.entries(statusCounts).map(([status, count]) => ({
        status,
        count,
      }));

      const activeChargers = chargers?.filter((c) => c.status === "AVAILABLE" || c.status === "OCCUPIED").length || 0;
      const faultedChargers = chargers?.filter((c) => c.status === "FAULTED").length || 0;
      const totalChargers = chargers?.length || 1;
      const utilizationRate = Math.round((activeChargers / totalChargers) * 100);

      // Revenue by day
      const revenueByDayMap: Record<string, { revenue: number; sessions: number }> = {};
      sessions?.forEach((s) => {
        const date = new Date(s.start_time).toISOString().split("T")[0];
        if (!revenueByDayMap[date]) {
          revenueByDayMap[date] = { revenue: 0, sessions: 0 };
        }
        revenueByDayMap[date].revenue += Number(s.total_cost) || 0;
        revenueByDayMap[date].sessions += 1;
      });

      const revenueByDay = Object.entries(revenueByDayMap)
        .map(([date, data]) => ({ date, ...data }))
        .sort((a, b) => a.date.localeCompare(b.date));

      // Top locations by sessions
      const locationStats: Record<string, { sessions: number; revenue: number }> = {};
      sessions?.forEach((s) => {
        const charger = chargers?.find((c) => c.charger_id === s.charger_id);
        const locationName = charger?.stations?.locations?.name || "Unknown";
        if (!locationStats[locationName]) {
          locationStats[locationName] = { sessions: 0, revenue: 0 };
        }
        locationStats[locationName].sessions += 1;
        locationStats[locationName].revenue += Number(s.total_cost) || 0;
      });

      const topLocations = Object.entries(locationStats)
        .map(([name, data]) => ({ name, ...data }))
        .sort((a, b) => b.sessions - a.sessions)
        .slice(0, 5);

      // Sessions by charger status (simulated from session data)
      const sessionsByStatus = [
        { status: "Completed", count: sessions?.filter((s) => s.end_time).length || 0 },
        { status: "In Progress", count: sessions?.filter((s) => !s.end_time).length || 0 },
      ];

      return {
        totalSessions,
        totalRevenue,
        totalKwh,
        activeChargers,
        faultedChargers,
        utilizationRate,
        sessionsByStatus,
        revenueByDay,
        topLocations,
        chargerStatusBreakdown,
      };
    },
  });
}
