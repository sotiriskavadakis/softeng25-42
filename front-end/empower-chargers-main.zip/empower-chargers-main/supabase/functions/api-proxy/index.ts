/**
 * Unified API Proxy Edge Function
 * 
 * Routes all API calls through this proxy to avoid CORS issues with the ngrok domain.
 * Supports: points, point details, reservation, healthcheck
 * 
 * Working endpoints (per Swagger spec):
 * - GET /api/points - List points with optional filters
 * - GET /api/getpoint/{id} - Get point details
 * - POST /api/reserve/{id} - Reserve a point (default 30 min)
 * - POST /api/reserve/{id}/{minutes} - Reserve with custom duration
 * - GET /api/healthcheck - System health check
 * 
 * Not implemented (return 500 on server):
 * - POST /api/updpoint/{id}
 * - POST /api/newsession
 * - GET /api/pointstatus/{pointid}/{from}/{to}
 */

const EXTERNAL_API_BASE = "https://heliced-evita-preblooming.ngrok-free.dev";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

interface ApiErrorResponse {
  call: string;
  timeref: string;
  originator: string;
  return_code: number;
  error: string;
  debuginfo: string;
}

function isApiErrorResponse(data: unknown): data is ApiErrorResponse {
  return (
    typeof data === "object" &&
    data !== null &&
    "return_code" in data &&
    "error" in data
  );
}

async function handleUpstreamResponse(
  response: Response,
  endpoint: string
): Promise<Response> {
  const contentType = response.headers.get("content-type") || "";
  
  if (!contentType.includes("application/json")) {
    // Non-JSON response - return as text
    const text = await response.text();
    return new Response(text, {
      status: response.status,
      headers: { ...corsHeaders, "Content-Type": contentType },
    });
  }

  const data = await response.json();

  // Check if it's an error response format from the API
  if (isApiErrorResponse(data)) {
    console.error(`[api-proxy] API Error on ${endpoint}:`, JSON.stringify(data));
    return new Response(JSON.stringify(data), {
      status: data.return_code || response.status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify(data), {
    status: response.status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function proxyRequest(
  method: string,
  path: string,
  body?: string
): Promise<Response> {
  const upstreamUrl = `${EXTERNAL_API_BASE}${path}`;
  
  console.log(`[api-proxy] ${method} ${upstreamUrl}`);

  const headers: Record<string, string> = {
    "Accept": "application/json",
    "ngrok-skip-browser-warning": "true",
  };

  if (body) {
    headers["Content-Type"] = "application/json";
  }

  try {
    const response = await fetch(upstreamUrl, {
      method,
      headers,
      body: body || undefined,
    });

    return handleUpstreamResponse(response, path);
  } catch (error) {
    console.error(`[api-proxy] Network error:`, error);
    return new Response(
      JSON.stringify({
        error: "Failed to connect to upstream API",
        message: error instanceof Error ? error.message : "Unknown network error",
      }),
      {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const action = url.searchParams.get("action");

  console.log(`[api-proxy] Action: ${action}, Method: ${req.method}`);

  try {
    switch (action) {
      // GET /api/points - List all points with optional filters
      case "points": {
        const params = new URLSearchParams();
        params.set("format", "json");
        
        // Forward allowed query params
        const allowedParams = ["min_lat", "max_lat", "min_lon", "max_lon", "status"];
        for (const param of allowedParams) {
          const value = url.searchParams.get(param);
          if (value !== null) {
            params.set(param, value);
          }
        }

        const path = `/api/points?${params.toString()}`;
        return proxyRequest("GET", path);
      }

      // GET /api/point?pointid={id} - Get point details
      case "point-details": {
        const pointId = url.searchParams.get("pointid");
        if (!pointId) {
          return new Response(
            JSON.stringify({ error: "Missing required parameter: pointid" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        // Use /api/point with query param
        const path = `/api/point?pointid=${encodeURIComponent(pointId)}`;
        return proxyRequest("GET", path);
      }

      // POST /api/reserve/{id} or /api/reserve/{id}/{minutes}
      case "reserve": {
        if (req.method !== "POST") {
          return new Response(
            JSON.stringify({ error: "Method not allowed. Use POST." }),
            { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const pointId = url.searchParams.get("pointid");
        const minutes = url.searchParams.get("minutes");

        if (!pointId) {
          return new Response(
            JSON.stringify({ error: "Missing required parameter: pointid" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        // Build path: /api/reserve/{id} or /api/reserve/{id}/{minutes}
        let path = `/api/reserve/${encodeURIComponent(pointId)}`;
        if (minutes) {
          path += `/${encodeURIComponent(minutes)}`;
        }

        return proxyRequest("POST", path);
      }

      // GET /api/healthcheck - System health
      case "healthcheck": {
        // Swagger shows /healthcheck, but actual path may be /api/admin/healthcheck
        // Try the admin path first as mentioned in the user's message
        const path = "/api/admin/healthcheck";
        return proxyRequest("GET", path);
      }

      default:
        return new Response(
          JSON.stringify({ 
            error: "Unknown action",
            message: "Valid actions: points, point-details, reserve, healthcheck" 
          }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }
  } catch (error) {
    console.error(`[api-proxy] Unexpected error:`, error);
    return new Response(
      JSON.stringify({
        error: "Internal proxy error",
        message: error instanceof Error ? error.message : "Unknown error",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
